## Freeze Requirements
```python
poetry export --without-hashes --format=requirements.txt > requirements.txt
```