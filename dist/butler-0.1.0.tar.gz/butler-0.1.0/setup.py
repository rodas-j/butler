# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['butler', 'butler.database']

package_data = \
{'': ['*']}

install_requires = \
['flask>=2.2.2,<3.0.0', 'gunicorn>=20.1.0,<21.0.0', 'langchain>=0.0.43,<0.0.44']

setup_kwargs = {
    'name': 'butler',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Freeze Requirements\n```python\npoetry export --without-hashes --format=requirements.txt > requirements.txt\n```',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
